package com.newsapp.userprofile.service;

import com.newsapp.userprofile.model.User;

public interface UserService {
    User registerUser(User user);
}
