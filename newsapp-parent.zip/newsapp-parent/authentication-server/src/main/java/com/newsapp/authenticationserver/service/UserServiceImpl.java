package com.newsapp.authenticationserver.service;

import com.newsapp.authenticationserver.exception.UserNotFoundException;
import com.newsapp.authenticationserver.model.User;
import com.newsapp.authenticationserver.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl {
    @Autowired
    private UserRepository userRepository;

    public boolean validateUserService(String userName, String password) throws UserNotFoundException {

        User user = userRepository.validateUser(userName, password);
        if(user != null)
            return true;
        else
            throw new UserNotFoundException("User with user name :" + userName +" is not found." );
    }
}
