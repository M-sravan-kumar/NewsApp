package com.newsapp.authenticationserver.exception;

import com.newsapp.authenticationserver.response.CustomResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    public ResponseEntity<CustomResponse<String>> getExample(UserNotFoundException e) {
        CustomResponse<String> customResponse = new CustomResponse<>();
        customResponse.setStatus("Not Found");
        customResponse.setData(e.getMessage());

        return new ResponseEntity<>(customResponse, HttpStatus.NOT_FOUND);
    }
}
