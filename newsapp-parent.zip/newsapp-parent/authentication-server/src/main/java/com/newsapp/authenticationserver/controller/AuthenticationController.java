package com.newsapp.authenticationserver.controller;

import com.newsapp.authenticationserver.exception.UserNotFoundException;
import com.newsapp.authenticationserver.request.LoginRequest;
import com.newsapp.authenticationserver.response.CustomResponse;
import com.newsapp.authenticationserver.service.UserServiceImpl;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.servlet.ServletException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(
    path = "/api/v1.0/auth"
)
@Slf4j
public class AuthenticationController {

    @Value("${newsapp.secret}")
    private String secret;

    private Map<String,String> map = new HashMap<>();
    @Autowired
    private UserServiceImpl userService;

    @PostMapping("/login")
    public ResponseEntity<?> doLogin(@RequestBody LoginRequest loginRequest){
        log.info(loginRequest.toString());
        try {
            String jwtToken = generateToken(loginRequest.getUserName(), loginRequest.getPassword());

            map.put("message", "User Successfully LoggedIn");

            map.put("token", jwtToken);

        } catch (Exception | UserNotFoundException e) {
            map.put("message", e.getMessage());
            map.put("token", null);
            return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
        }

        return new ResponseEntity<>(map,HttpStatus.OK);
    }

    @GetMapping("/getusername")
    public String getUserName(@RequestHeader(name = "Authorization") String token) throws ServletException {
        log.info("get user name request in controller of auth");
        return getUserNameFromToken(token);
    }

    private String generateToken(String username, String password) throws ServletException, UserNotFoundException {
        String jwtToken = "";
        if(username == null || password == null) {
            throw new ServletException("Please send valid username and password");
        }
        //validate user aginst db
        boolean flag = userService.validateUserService(username, password);
        if(!flag)
            throw new ServletException("Invalid Credentials");
        else {
            jwtToken = Jwts.builder()
                    .setSubject(username)
                    .setIssuedAt(new Date())
                    .setExpiration(new Date(System.currentTimeMillis() + 3000000))
                    .signWith(SignatureAlgorithm.HS256, secret)
                    .compact();
        }
        return jwtToken;
    }

    private String getUserNameFromToken(String token) throws ServletException {
        if(token == null || !token.startsWith("Bearer"))
        {
            throw new ServletException("Missing or Invalid Authentication Header");
        }
        String jwtToken = token.substring(7);
        Claims claims = Jwts.parser().setSigningKey("MyOwnSecret").parseClaimsJws(jwtToken).getBody();
        return claims.get("sub",String.class);
    }



}
