package com.newsapp.wishlistservice.controller;

import com.newsapp.wishlistservice.exception.ArticleAlreadyWishlisted;
import com.newsapp.wishlistservice.exception.NoArticlesWishlisted;
import com.newsapp.wishlistservice.model.NewsArticle;
import com.newsapp.wishlistservice.model.WishList;
import com.newsapp.wishlistservice.service.AuthenticationServerFeignClient;
import com.newsapp.wishlistservice.service.WishListService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping(
        path = "/api/v1.0/wishlist"
)
@Slf4j
public class NewsWishlistController {

    @Autowired
    private WishListService wishListervice;

    @Autowired
    private AuthenticationServerFeignClient feignClient;

    @PostMapping
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<NewsArticle>> addArticleToWishList(@RequestBody NewsArticle article, @RequestHeader("Authorization") String token){
        try{
            log.info(feignClient.getUserName(token));
            String userName = feignClient.getUserName(token);
            WishList wishList = wishListervice.addArticleToWishList(userName,article);
            return new ResponseEntity<>(
                    wishList.getArticles(),
                    HttpStatus.CREATED
            );
        }
        catch (Exception e){
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        } catch (ArticleAlreadyWishlisted e) {
            throw new RuntimeException(e);
        }
    }

    @GetMapping
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<NewsArticle>> getWishListedArticles(@RequestHeader("Authorization") String token) throws NoArticlesWishlisted {
        String userName = feignClient.getUserName(token);
        return new ResponseEntity<>(wishListervice.getWishListedArticles(userName),HttpStatus.OK);
    }
}
