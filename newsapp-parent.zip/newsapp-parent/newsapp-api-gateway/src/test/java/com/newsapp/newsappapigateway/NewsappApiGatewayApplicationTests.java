package com.newsapp.newsappapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsappApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
